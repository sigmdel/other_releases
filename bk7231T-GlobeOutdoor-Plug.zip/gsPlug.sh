#!/usr/bin/bash

# Set relay 1 or 2 of Globe Smart Plug (sku 50151) on or off
# Firmware: OpenBK7231T (version 1.17.776)

if [ $# -ne 3 ]; then
  echo "Missing or extra argument"
  echo  "Usage: bash $0 <dev> <channel> <value>"
  echo  "  <dev> = 1 or 2 for PriseExt<dev>"
  echo  "  <channel> = 1 or 2 for left or right socket"
  echo  "  <value> = 0 or 1 for OFF or ON"
  exit 1
fi

# get arguments - NO ERROR CHECKING
DEV=gsPlug$1
CHANNEL=$2
VALUE=$3

# debug
#echo "DEV = $DEV, CHANNEL = $CHANNEL, VALUE = $VALUE"

mosquitto_pub -h 192.168.1.22 -t $DEV/$CHANNEL/set -m $VALUE --quiet
if [ $? -ne 0 ]; then
  echo "Could not set value"
  exit 2
fi
echo "OK"
