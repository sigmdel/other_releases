
# Manifest

1. **autoexec.bat**
   
   A batch file executed by the plug firmware to set up event handlers when it is booted. The handlers publish MQTT topics that will update the Domoticz database when an outlet is turned on or off via the device web interface or manually with the device button.

   Upload the file to the device file system with the Web application.


1. **autoexec-html.bat**

   Similar to the above, except HTML requests sent directly to the Beken device are used instead of MQTT topics. Rename the file to **autoexec.bat** when using it.


1. **Dbl_Plug_L.zip**

   A Domoticz icon file for the left (as seen from above) socket. Import into the Domoticz database with **Setup » More Options » Custom Icon**.

1. **Dbl_Plug_R.zip**

   A Domoticz icon file for the right socket.
   

1. **gsPlug.sh**

   Bash script for the On and Off Actions of the Domoticz virtual switches. When the virtual device is turned on or off, the script is run to set the appropriate channel to the correct state on the physical device.
   
1. **readme.md**

   This file.

1. **template.json**

   A template that can be used to configure OpenBK7231T in the Web Application. Because of an issue mentioned below, this is not discussed in the [post](https://sigmdel.ca/michel/ha/domoticz/beken7231_domoticz_en.html). To use the template, go to the **Import** tab, and copy and paste the definition in the **Enter template here** box. The **Check generated script (modify if you want)** box should then automatically be filled with the following 
   script

   ```
   ClearIO // clear old GPIO/channels
   lfs_format // clear LFS
   StartupCommand ""  // clear STARTUP
   stopDriver *  // kill drivers
   backlog setPinRole 6 Rel; setPinChannel 6 1
   backlog setPinRole 7 Rel; setPinChannel 7 2
   backlog setPinRole 10 LED_n; setPinChannel 10 2
   backlog setPinRole 24 Btn; setPinChannel 24 1 2
   backlog setPinRole 26 LED_n; setPinChannel 26 1
   Flags 1024
   ```   
      
   and **OK! Generated.** should be displayed. In *principle* clicking on **Clear OBK and apply new transcript from above** should configure the plug. Unfortunately, there is a bug such that the flags are not correctly 
   set and it will be necessary to remove extraneous flag settings manually 
   (see [issue 1458](https://github.com/openshwprojects/OpenBK7231T_App/issues/1458) for details)


# Reference

[A Beken BK7231T Device In Domoticz](https://sigmdel.ca/michel/ha/domoticz/beken7231_domoticz_en.html) - *Adding two Globe outdoor smart plugs to a home automation system showing how OpenBK7231T can be made to work with Domoticz*
