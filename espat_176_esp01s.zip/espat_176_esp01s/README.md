
# ESP-AT Firmware (V1.7.6) for the ESP-01S Module

2024-11-01

ESP-AT was compiled for the ESP-01s module (1 MB flash memory) against the *legacy* ESP8266 NonOS SDK.

## Version details reported as by the AT+GMR in ESP-AT

    AT version:1.7.6.0(Jan 24 2022 08:56:02)
    SDK version:3.0.6-dev(072755c)
    compile time:Jun 17 2024 07:37:49
    Bin version(Wroom 02):1.7.6


## Flashing the firmware

1. Extract the ESP-AT firmware `espat_176_esp01s.bin`.

2. Upload the firmware to the module with `esptool.py` from the directory which contains the binary file.

   ```
   $ esptool.py -p /dev/ttyUSB1 -b 460800 write_flash -e -fm qio -ff 80m -fs 1MB 0 espat_176_esp01s.bin
   ```

   - Of course, adjust the device path as needed.

   - Some modules may not function at 460800 baud; try 115200 in that case.

   - Some modules may not support flash mode qio; try `-fm dout` in that case.

   - Some modules may not support an 80 Mhz frequency; try `-ff 40m` in that case.

## Reference

See [Installing the AT Firmware on an ESP-01S](https://sigmdel.ca/michel/ha/esp8266/ESP01_AT_Firmware_en.html) for details.
