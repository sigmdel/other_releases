
# ESP-AT Firmware (V2.2.1) for the ESP-01S Module

2024-11-05

ESP-AT was compiled for the ESP-01s module (1 MB flash memory) against the ESP8266 RTOS SDK.

## Version details reported as by the AT+GMR in ESP-AT

    AT version:2.2.2.0-dev(e3958a6 - ESP8266 - Oct 30 2024 02:42:04)
    SDK version:v3.4-84-ge19ff9af
    compile time(f37fbc77):Nov  5 2024 15:58:02
    Bin version:2.2.1(ESP8266_1MB)


## Flashing the firmware

1. Extract the ESP-AT firmware `espat_221_esp01s.bin`.

2. Upload the firmware to the module with `esptool.py` from the directory which contains the binary file.

   ```
   $ esptool.py -p /dev/ttyUSB1 -b 460800 write_flash -e -fm qio -ff 80m -fs 1MB 0 espat_221_esp01s.bin
   ```

   - Of course, adjust the device path as needed.

   - Some modules may not function at 460800 baud; try 115200 in that case.

   - Some modules may not support flash mode qio; try `-fm dout` in that case.

   - Some modules may not support an 80 Mhz frequency; try `-ff 40m` in that case.

## Reference

See [Installing the AT Firmware on an ESP-01S](https://sigmdel.ca/michel/ha/esp8266/ESP01_AT_Firmware_en.html) for details.
